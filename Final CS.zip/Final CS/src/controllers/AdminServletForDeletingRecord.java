package controllers;
import java.io.*;  
import java.sql.*;  

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;  
import javax.servlet.http.*; 

import service.DeleteRecordDaoService;
import service.StatusUpdateService;


import beans.BeanForDeletingRecord;



public class AdminServletForDeletingRecord extends HttpServlet {  
	
	private static final long serialVersionUID = 1L;

	public void doPost(HttpServletRequest request, HttpServletResponse response)  
			throws ServletException, IOException {  
//Set Response type
		response.setContentType("text/html");  

		String bookingId = request.getParameter("bookingId1");  
		
		System.out.println(bookingId);	
		
		
		BeanForDeletingRecord booking1 = new BeanForDeletingRecord();
		
		booking1.setBookingId(bookingId);
		
        request.setAttribute("booking1",booking1);
		

		DeleteRecordDaoService deleteRecordService= new DeleteRecordDaoService();
		System.out.println("fdwsad");
        try {
		int j = deleteRecordService.deleteRecordDao(booking1);
			 if(j==0){
				 request.setAttribute("mesg", "Delete Record.");
				 RequestDispatcher rd=request.getRequestDispatcher("AdminUpdates.jsp");
			     rd.include(request, response); 
					System.out.println("def");

		        }
			 else{
				 request.setAttribute("mesg", "Delete Record failed");
			     RequestDispatcher rd=request.getRequestDispatcher("DeleteRecordByAdmin.html");
			     rd.include(request, response);   	 
				 
			 }

		} catch (ClassNotFoundException | SQLException e) {
			
			e.printStackTrace();
		}
	}


}
