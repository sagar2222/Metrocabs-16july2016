package beans;

public class BeanForDeletingRecord {
	private String bookingId;


	public  BeanForDeletingRecord() {
	}
	
	public  BeanForDeletingRecord(String bookingId) {

			this.setBookingId(bookingId);
	}

	public String getBookingId() {
		return bookingId;
	}

	public void setBookingId(String bookingId) {
		this.bookingId = bookingId;
	}




}
