package beans;

public class BeanForBookingId {
	private String bookingId, contactNumber;
	
	public  BeanForBookingId() {
		
	}
public  BeanForBookingId(String bookingId,String contactNumber) {
		this.setBookingId(bookingId);
		this.setContactNumber(contactNumber);
	}
public String getContactNumber() {
	return contactNumber;
}
public void setContactNumber(String contactNumber) {
	this.contactNumber = contactNumber;
}
public String getBookingId() {
	return bookingId;
}
public void setBookingId(String bookingId) {
	this.bookingId = bookingId;
}
	
	
	
	

}
