package beans;

public class BeanForStatusUpdate {
   private String bookingId, status;
	
	
	public  BeanForStatusUpdate() {
	
	}
	
	public  BeanForStatusUpdate(String bookingId,String status) {
		this.bookingId=bookingId;
		this.setStatus(status);
	}

	
	
	public String getBookingId() {
		return bookingId;
	}

	public void setBookingId(String bookingId) {
		this.bookingId = bookingId;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
	
	
	
}
