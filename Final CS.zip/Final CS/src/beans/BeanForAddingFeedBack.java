package beans;

public class BeanForAddingFeedBack {
 private String bookinId, feedBack;
 
 public  BeanForAddingFeedBack() {
	 
 }

 
public  BeanForAddingFeedBack(String bookinId, String feedBack) {
	 this.setBookinId(bookinId);
	 this.setFeedBack(feedBack);
 }


public String getFeedBack() {
	return feedBack;
}


public void setFeedBack(String feedBack) {
	this.feedBack = feedBack;
}


public String getBookinId() {
	return bookinId;
}


public void setBookinId(String bookinId) {
	this.bookinId = bookinId;
}
 
 
}
