package beans;

public class BeanForDriverDetails {
	
	private String cabNumber;
	private String driverName;
	private String employeeNumber;
	private String pickupTime;
	private String cabColor;
	private String driverMobile;
	private String cost;
	private String bookingId;
	
	
	public BeanForDriverDetails(){}
	
	public BeanForDriverDetails(String cabNumber,String driverName,String employeeNumber,String pickupTime,String cabColor,String driverMobile,String cost,String bookingId)
	 {
		this.bookingId=bookingId;
		this.cabColor=cabColor;
		this.cabNumber=cabNumber;
		this.cost=cost;
		this.driverMobile=driverMobile;
		this.driverName=driverName;
		this.employeeNumber=employeeNumber;
		this.pickupTime=pickupTime;
	 }




public String getCabNumber()
{
  return cabNumber;
}

 public void setCabNumber(String cabNumber)
 {
   this.cabNumber=cabNumber;
  }



public String getDriverName()
{
  return driverName;
}

 public void setDriverName(String driverName)
 {
   this.driverName=driverName;
  }




public String getEmployeeNumber()
{
  return employeeNumber;
}

 public void setEmployeeNumber(String employeeNumber)
 {
   this.employeeNumber=employeeNumber;
  }



public String getPickUpTime()
{
  return pickupTime;
}

 public void setPickUpTimer(String pickUpTime)
 {
   this.pickupTime=pickUpTime;
  }




public String getCabColor()
{
  return cabColor;
}

 public void setCabColorr(String cabColor)
 {
   this.cabColor=cabColor;
  }




public String getDriverMobile()
{
  return driverMobile;
}

 public void setdriverMobile(String driverMobile)
 {
   this.driverMobile=driverMobile;
  }




public String getCost()
{
  return cost;
}

 public void setCost(String cost)
 {
   this.cost=cost;
  }





public String getBookingId()
{
  return bookingId;
}

 public void setBookingId(String bookingId)
 {
   this.bookingId=bookingId;
  }
	
}
