package beans;

public class BeansForMetroCabs {
    private String firstName, lastName, date, timeOfBooking, city, pickupPlace, landMark, destination, typeOfVehicle, serviceType, email, feedBack, bookingId ;
    private String numberOfPersons, idCardNumber, contactNumber;

//Default Constructor
public BeansForMetroCabs() {

}

public BeansForMetroCabs(String firstName, String lastName, String date, String timeOfBooking, String city, String pickupPlace, String landMark, String destination, String typeOfVehicle, String serviceType, String email, String feedBack, String numberOfPersons, String idCardNumber, String contactNumber, String bookingId) {
this.firstName=firstName;
this.lastName=lastName;
this.date=date;
this.timeOfBooking=timeOfBooking;
this.city=city;
this.pickupPlace=pickupPlace;
this.landMark=landMark;
this.destination=destination;
this.typeOfVehicle=typeOfVehicle;
this.serviceType=serviceType;
this.email=email;
this.numberOfPersons=numberOfPersons;
this.idCardNumber=idCardNumber;
this.contactNumber=contactNumber;
this.bookingId=bookingId;
this.feedBack=feedBack;
}


//Getters
public String getFirstName() {
	return firstName;
}


public String getLastName() {
	return lastName;
}

public String getDate() {
	return date;
}

public String getTimeofBooking() {
	return timeOfBooking;
}

public String getCity() {
	return city;
}

public String getPickupPlace() {
	return pickupPlace;
}

public String getLandMark() {
	return landMark;
}

public String getDestination() {
	return destination;
}

public String getTypeOfVehicle() {
	return typeOfVehicle;
}

public String getServiceType() {
	return serviceType;
}

public String getIdCardNumber() {
	return idCardNumber;
}

public String getNumberOfPersons() {
	return numberOfPersons;
}

public String getEmail() {
	return email;
}

public String getContactNumber() {
	return contactNumber;
}

public String getBookingId() {
	return bookingId;
}

public String getFeedBack() {
	return feedBack;
}






//Setters
public void setFirstName(String firstName) {
	this.firstName = firstName;
}



public void setLastName(String lastName) {
	this.lastName = lastName;
}



public void setDate(String date) {
	this.date = date;
}



public void settimeOfBooking(String timeOfBooking) {
	this.timeOfBooking = timeOfBooking;
}


public void setCity(String city) {
	this.city = city;
}


public void setPickupPlace(String pickupPlace) {
	this.pickupPlace = pickupPlace;
}


public void setLandMark(String landMark) {
	this.landMark = landMark;
}


public void setDestination(String destination) {
	this.destination = destination;
}


public void setTypeOfVehicle(String typeOfVehicle) {
	this.typeOfVehicle = typeOfVehicle;
}


public void setServiceType(String serviceType) {
	this.serviceType = serviceType;
}


public void setEmail(String email) {
	this.email = email;
}



public void setNumberOfPersons(String numberOfPersons) {
	this.numberOfPersons = numberOfPersons;
}


public void setIdCardNumber(String idCardNumber) {
	this.idCardNumber = idCardNumber;
}



public void setContactNumber(String contactNumber) {
	this.contactNumber = contactNumber;
}


public void setBookingId(String bookingId) {
	this.bookingId = bookingId;
}



public void setFeedBack(String feedBack) {
	this.feedBack = feedBack;
}




}