package service;

import java.sql.SQLException;

import beans.BeanForDeletingRecord;
import dao.DeleteRecordDao;
import daoImplementation.DeleteRecordDaoImplementation;

public class DeleteRecordDaoService {
	
	
	public int deleteRecordDao(BeanForDeletingRecord booking1) throws ClassNotFoundException, SQLException{
		DeleteRecordDao deleteRecord = new DeleteRecordDaoImplementation();
        return deleteRecord.deleteRecordDao(booking1);	
	
	
}

	

	
	
	

}
