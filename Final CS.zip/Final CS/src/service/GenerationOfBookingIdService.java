package service;
import java.sql.SQLException;

import  beans.BeanForBookingId;
import daoImplementation.GenerateBookingIdDaoImplementation;
import dao.GenerationOfBookingIdDao;


public class GenerationOfBookingIdService {

	
	
	
	public int generateBookingId(BeanForBookingId booking1) throws ClassNotFoundException, SQLException{
		GenerationOfBookingIdDao bookDao = new GenerateBookingIdDaoImplementation();
        return bookDao.generateBookingIdDao(booking1);
    }

	
	
	
}






	