package daoImplementation;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.PreparedStatement;

import beans.BeanForStatusUpdate;
import connections.ConnectionToDB;
import dao.StatusUpdateDao;
import beans.BeanForDriverDetails;




public class StatusUpdateImplementation implements StatusUpdateDao{

	
public int updateStatusDao(BeanForStatusUpdate booking1,BeanForDriverDetails driver1) throws ClassNotFoundException, SQLException{
	
		
	Connection con = ConnectionToDB.getConnection();
	PreparedStatement st= con.prepareStatement("insert into metrocabs_status values(?,?)");
	st.setString(1,booking1.getBookingId());
	st.setString(2, booking1.getStatus());
	
	
	if(booking1.getStatus().equals("Approved"))
	{
	 
	 System.out.println("This has to be printed");
	 String x=booking1.getBookingId();
	 PreparedStatement pst=con.prepareStatement("insert into metrocabs_cabs(cabnumber,drivername,employeenumber,pickuptime,cabcolor,drivermobile,cost,bookingid) values(?,?,?,?,?,?,?,?)");
	 pst.setString(1,driver1.getCabNumber());
	 pst.setString(2, driver1.getDriverName());
	 pst.setString(2, driver1.getEmployeeNumber());
	 pst.setString(3, driver1.getPickUpTime());
	 pst.setString(4, driver1.getPickUpTime());
	 pst.setString(5,driver1.getCabColor());
	 pst.setString(6, driver1.getDriverMobile());
	 pst.setString(7, driver1.getCost());
	 pst.setString(8, booking1.getBookingId());
	 pst.executeUpdate();
	}
	return st.executeUpdate();

	
	

}
			
		
	



}


	
	
		
	



		

	

