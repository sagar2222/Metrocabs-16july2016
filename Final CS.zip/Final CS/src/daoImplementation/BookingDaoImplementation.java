package daoImplementation;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import beans.BeansForMetroCabs;
import dao.BookingDao;
import connections.ConnectionToDB;

public class BookingDaoImplementation implements BookingDao {
	
	public int bookUser(BeansForMetroCabs booking1) throws ClassNotFoundException, SQLException{
		
		Connection con = ConnectionToDB.getConnection();
		PreparedStatement ps= con.prepareStatement("INSERT INTO METROCABS VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,to_char(bookId.nextval))");  

		ps.setString( 1,booking1.getFirstName());  
		ps.setString( 2,booking1.getLastName());  
		ps.setString( 3,booking1.getTimeofBooking());  
		ps.setString( 4,booking1.getCity());  
		ps.setString( 5,booking1.getPickupPlace()); 
		ps.setString( 6,booking1.getLandMark()); 
		ps.setString( 7,booking1.getDestination());
		ps.setString( 8,booking1.getTypeOfVehicle());
		ps.setString( 9,booking1.getServiceType());
		ps.setString(10,booking1.getEmail());
		ps.setString(11,booking1.getNumberOfPersons());
		ps.setString(12,booking1.getIdCardNumber());
		ps.setString(13,booking1.getDate());
		ps.setString(14,booking1.getContactNumber());
		ps.setString(15, null);
		int i=ps.executeUpdate();  
        return i;
	}
}
