package daoImplementation;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import beans.BeanForDeletingRecord;
import connections.ConnectionToDB;
import dao.DeleteRecordDao;

public class DeleteRecordDaoImplementation implements DeleteRecordDao{

	
	
	
	
	
public int deleteRecordDao(BeanForDeletingRecord booking1) throws ClassNotFoundException, SQLException{
		
	Connection con = ConnectionToDB.getConnection();
	Statement st= con.createStatement();
	
	
	System.out.println("qwe");

	//Step 4: Creating SQL query , executing and processing
	System.out.println("booking id"+booking1.getBookingId());
	String deleteQuery= "DELETE FROM METROCABS WHERE BOOKINGID='"+booking1.getBookingId()+"'";
	
			
	//Step 4.1 :Executing SQL Statement
	ResultSet rs= st.executeQuery(deleteQuery);
	

	rs.close();
	
	System.out.println("deleted id"+booking1.getBookingId());

	int i = st.executeUpdate(deleteQuery);
	System.out.print("i is  "+i );
	return i;
	

}		
}	
		

	



