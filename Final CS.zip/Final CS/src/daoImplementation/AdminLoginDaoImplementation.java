package daoImplementation;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import connections.ConnectionToDB;
import beans.AdminLogin;
import dao.AdminLoginDao;



public class AdminLoginDaoImplementation implements AdminLoginDao{


	 public String validateUser(AdminLogin login) throws ClassNotFoundException, SQLException{

            String username=login.getUserName();
            String password=login.getPassWord();
            String usr=null;
	        String pwd=null;
	        String match=null;
	        

            
	        System.out.println(username);
	        System.out.println(password);

	        
	        
	        
	        Connection con = ConnectionToDB.getConnection();
	        PreparedStatement pst=con.prepareStatement("SELECT * FROM METROCABS_ADMIN");

	      //  String validateQuery="SELECT * FROM METROCABS_ADMIN WHERE USERNAME='"+username+"' AND PASSWORD='"+password+"'";

	       

	        
	        
	        ResultSet rs = pst.executeQuery();
	        
	        
	        if(rs.next()){
	         usr=rs.getString("USERNAME");
	         System.out.println(usr);
	         pwd=rs.getString("PASSWORD");

		        
	        }
	        

	       rs.close();
	      
	        System.out.println(pwd);
	        System.out.println(usr);
	        
	/*
	        	if(login.getPassWord()==pwd && login.getUserName()==usr){
	        	
	        	 match="match";
	 	        System.out.println(match);

	        }  */
	        
	        
	        
	        
	        
       if(pwd.equalsIgnoreCase(password)){
        		System.out.println("pwd is ok");
	        	if(usr.equalsIgnoreCase(username)){
	        	 match="match";
	 	        System.out.println(match);
	 	       System.out.println("usr is ok");
	        }
        	}
	        
	        
	        
	        
	        
	        System.out.println("User Login");

	        System.out.println(match);

	        
	      
	        return match;
	    }
	}

